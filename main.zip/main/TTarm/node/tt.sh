#!/bin/bash
LANG=en_US.UTF-8
#PJ小宇
cd
e=$(lsblk | grep mnt | grep -Eo "/m.*" | cut -d "s" -f 1)

A="$e"
B="mnt"
if [[ $A == *$B* ]]
then
 cd
else
 mount LABEL=272440 /mnts||(
 cd&&lsblk -al | awk 'NR>1' | grep -v 'mmcblk1p' | grep -E "T|G" | awk '{if($4>=1) print $1}'| while read procid
 do
 mount /dev/$procid /mnts
done
 )
 fi
cd