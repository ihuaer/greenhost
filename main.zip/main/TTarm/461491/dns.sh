#!/bin/sh
#PJ小宇

read -p "请输入你的路由IP:" i
echo nameserver $i >>/etc/resolv.conf
