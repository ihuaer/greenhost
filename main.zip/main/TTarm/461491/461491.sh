#!/bin/sh
#自动改mac
#PJ小宇
mac=`openssl rand -hex 6 | sed -E "s/(..)/\1:/g; s/:$//" | cut -c 1-14`
echo hwaddress ether 00:$mac>/root/xy.txt
sed -i "7s/.*/`sed -ne 1p /root/xy.txt`/" /etc/network/interfaces