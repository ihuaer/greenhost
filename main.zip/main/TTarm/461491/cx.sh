#!/bin/bash
LANG=en_US.UTF-8
name="ttnode"
path="/root"
unamem=`uname -m`
info="\033[32m[信息]\033[0m"
case $unamem in
*armv7*)
	osarch=513898
;;
*armv8*)
	osarch=513897
;;
*arm64*)
	osarch=513897
;;
*aarch64*)
	osarch=513897
;;
*)
	echo -e "$info 暂不支持此系统!"
	echo -e "$info 请前往官方网站下载对应程序!"
	exit 1
#513898=linux_arm-7
#513897=linux_arm64
;;
esac
cd $path/TTarm/node
wget --no-check-certificate https://gitee.com/pj-xiaoyu/cx/attach_files/$osarch/download/ttnode
exit 0