#!/bin/sh

#PJ小宇
#甜糖邀请码461491

cd /root

rm -f main.zip

cd /root

rm -f 461491.sh

cd /root

rm -f xy.sh

cd /root

rm -f dns.sh

cd /root

rm -rf /usr/node

sed -i '/\/usr\/node/d' /etc/crontab

#sed -i "5a service sshd start\nservice crond start" /etc/rc.local

sed -i "15a * * * * * root /usr/node/tt.sh\n* * * * * root /usr/node/crash_monitor.sh" /etc/crontab

cd /.

mkdir mnts /usr/node 2>/root/null

chmod -R 777 /root/TTarm

cd /root/TTarm

/bin/cp -rf 461491/*  /root

cd /root

sh cx.sh

cd /root/TTarm

/bin/cp -rf node/*  /usr/node

cd /usr

chmod -R 777 /usr/node

cd /root

echo -e "\033[31m  下载累了吧，稍微休息3秒钟吧！ \033[0m"
sleep 3s
cd&&sudo bash 461491.sh

#for i in `seq 1 5`
#do
sh 461491.sh
#done
#貌似不执行，改手动，哈哈

echo 'nameserver 119.29.29.29' >/etc/resolv.conf

cd /root

rm -f main.zip

rm -f cx.sh

cd /root

rm -rf /root/TTarm&&

echo -e "\033[31m  恭喜你，甜糖已经成功启动！新人填写甜糖邀请码：461491即可获得15张加成卡。你的支持是我的动力---@PJ小宇 \033[0m"
echo "   Congratulations, Tiantang has been started successfully! New people fill in Tiantang invitation code: 461491 can get 15 bonus cards. Your support is my driving force----@PJxiaoyu"
echo "   如需帮助可加入甜糖QQ群:321388890 或咨询QQ:898811295"
cd